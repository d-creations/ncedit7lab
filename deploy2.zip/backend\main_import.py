import sys
import os
import base64
import hashlib
import hmac

# Add root directory to sys.path to resolve 'backend' imports on Azure
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi import FastAPI, Request, HTTPException, Header, Depends
from fastapi.responses import FileResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
import json
import logging
import math
from typing import List, Dict, Any, Optional
import re
import traceback
import uuid
from pathlib import Path
import importlib.util
from pydantic import BaseModel
from backend.turning_reference import engine_pose_request, resolve_turning_references

# Transfer Service
try:
    from backend.transfer.interface import TransferError
    from backend.transfer.router import router as transfer_router
    TRANSFER_IMPORT_OK = True
except ImportError:
    try:
        from transfer.interface import TransferError
        from transfer.router import router as transfer_router
        TRANSFER_IMPORT_OK = True
    except ImportError as e:
        import logging
        logging.exception(f"Failed to import transfer.router: {e}")
        TRANSFER_IMPORT_OK = False
        class TransferClientBase:
            pass
        def get_transfer_client():
            return None
        def get_demo_transfer_client():
            return None
        transfer_router = None
        class TransferError(Exception): pass

# Simple security: API Key to prevent basic bot requests
API_KEY = os.environ.get("API_KEY", "nc-edit7-secret-key")
ENABLE_TRANSFER = os.environ.get("ENABLE_TRANSFER", "True").lower() in ("true", "1", "t", "yes")

async def verify_api_key(x_api_key: Optional[str] = Header(None)): return True

# Ensure ncplot7py/src is in sys.path for F1/Code deployment where PYTHONPATH env var might not be set easily
# We assume this file is in backend/main_import.py, and ncplot7py is at ../ncplot7py
try:
    current_dir = Path(__file__).resolve().parent
    package_src = current_dir.parent / "ncplot7py" / "src"
    if package_src.exists() and str(package_src) not in sys.path:
        sys.path.insert(0, str(package_src))
except Exception:
    pass


def resolve_machines_config_path() -> Optional[Path]:
    local_config = ROOT_DIR / "ncplot7py" / "config" / "machines.json"
    if local_config.exists():
        return local_config

    spec = importlib.util.find_spec("ncplot7py")
    if spec is None or spec.origin is None:
        return None

    package_root = Path(spec.origin).resolve().parent
    candidates = [
        package_root / "config" / "machines.json",
        package_root.parent / "config" / "machines.json",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate

    return None

# Import ncplot7py internals
try:
    from ncplot7py.application.nc_execution import NCExecutionEngine
    from ncplot7py.infrastructure.machines.base_stateful_control import UniversalConfigDrivenControl
    from ncplot7py.cli.main import bootstrap as cli_bootstrap
    from ncplot7py.domain.machines import (
        get_available_machines,
        get_machine_regex_patterns,
        get_machine_config,
    )
    from ncplot7py.domain.cnc_state import CNCState
    from ncplot7py.domain.tool_compensation import load_tool_data
    from ncplot7py.domain.simulation_contract import (
        SimulationContractError, validate_pose_request,
    )
    from ncplot7py.domain.exceptions import ExceptionNode
except Exception as e:
    logging.error(f"Failed to import ncplot7py: {e}")
    logging.error(traceback.format_exc())
    # If package isn't importable in some environments, we will raise at runtime
    NCExecutionEngine = None  # type: ignore
    UniversalConfigDrivenControl = None  # type: ignore
    cli_bootstrap = None  # type: ignore
    get_available_machines = None # type: ignore
    get_machine_regex_patterns = None # type: ignore
    CNCState = None  # type: ignore
    ExceptionNode = None  # type: ignore

logging.basicConfig(level=logging.INFO)
telemetry_logger = logging.getLogger(__name__)
azure_monitor_enabled = False

if os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING"):
    try:
        from azure.monitor.opentelemetry import configure_azure_monitor
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
        configure_azure_monitor(
            logger_name=__name__,
            instrumentation_options={"fastapi": {"enabled": False}},
        )
        azure_monitor_enabled = True
        telemetry_logger.info("Azure Monitor telemetry enabled")
    except Exception:
        telemetry_logger.exception("APPLICATIONINSIGHTS_CONNECTION_STRING is set but Azure Monitor initialization failed")

app = FastAPI(title="ncplot7py-adapter-import")
if azure_monitor_enabled:
    FastAPIInstrumentor.instrument_app(app)

if transfer_router:
    app.include_router(transfer_router)

@app.exception_handler(TransferError)
async def transfer_error_handler(request: Request, exc: TransferError):
    print(f"[VSCODE_NOTIFICATION] ERROR: {str(exc)}", flush=True)
    return JSONResponse(status_code=400, content={"detail": str(exc)})

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    # Only pop up VS Code notifications for 5xx errors or explicit 400 bad requests to avoid annoying 404 popups
    if exc.status_code >= 400:
        print(f"[VSCODE_NOTIFICATION] ERROR: {exc.detail}", flush=True)
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    print(f"[VSCODE_NOTIFICATION] ERROR: Internal Server Error: {str(exc)}", flush=True)
    return JSONResponse(status_code=500, content={"detail": "Internal Server Error"})

# Security: Trusted Host Middleware
# Prevents Host Header attacks. In Azure, this should be set to your domain (e.g., "nc-edit7.azurewebsites.net").
# For development, "*" is acceptable.
app.add_middleware(
    TrustedHostMiddleware, 
    allowed_hosts=os.environ.get("ALLOWED_HOSTS", "*").split(",")
)

# Security: CORS
# Restrict origins in production using ALLOWED_ORIGINS env var.
_allowed_origins_env = os.environ.get("ALLOWED_ORIGINS", "").strip()
if _allowed_origins_env == "*":
    allowed_origins = ["*"]
    logging.warning("ALLOWED_ORIGINS='*' — allowing all origins. Unsafe for production.")
elif _allowed_origins_env:
    allowed_origins = [o.strip() for o in _allowed_origins_env.split(",") if o.strip()]
else:
    allowed_origins = []
    logging.info("ALLOWED_ORIGINS not set — CORS will not allow cross-origin requests. Use this in production or set explicit origins for development.")

_allow_credentials = os.environ.get("ALLOW_CREDENTIALS", "True").lower() in ("true", "1", "t", "yes")
if "*" in allowed_origins and _allow_credentials:
    logging.warning("CORS: allow_credentials=True with '*' origin may be rejected by browsers. Specify explicit origins or set ALLOW_CREDENTIALS=False.")

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=_allow_credentials,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security: HTTP Headers
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    # Prevent MIME sniffing
    response.headers["X-Content-Type-Options"] = "nosniff"
    # Clickjacking protection / iframe embedding
    #
    # Default: deny framing.
    # If you need to embed this app in an <iframe>, set FRAME_ANCESTORS, e.g.:
    #   FRAME_ANCESTORS="https://www.star-ncplot.com"
    #
    # Prefer CSP `frame-ancestors` (modern). X-Frame-Options does not support
    # allowing specific external origins reliably across browsers.
    frame_ancestors = os.environ.get("FRAME_ANCESTORS", "").strip()
    if frame_ancestors:
        new_fa = f"frame-ancestors {frame_ancestors};"
        existing_csp = response.headers.get("Content-Security-Policy")
        if existing_csp:
            if "frame-ancestors" in existing_csp:
                response.headers["Content-Security-Policy"] = re.sub(
                    r"frame-ancestors[^;]*;?",
                    new_fa,
                    existing_csp,
                    flags=re.IGNORECASE,
                ).strip()
            else:
                response.headers["Content-Security-Policy"] = f"{existing_csp.rstrip()}; {new_fa}".strip()
        else:
            response.headers["Content-Security-Policy"] = new_fa

        # Ensure we don't block framing via X-Frame-Options.
        if "X-Frame-Options" in response.headers:
            del response.headers["X-Frame-Options"]
    else:
        response.headers["X-Frame-Options"] = "DENY"
    # Enable XSS protection in older browsers
    response.headers["X-XSS-Protection"] = "1; mode=block"
    # Enforce HTTPS (HSTS) - 1 year
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    # Referrer Policy
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    return response

def derive_telemetry_user_id(principal_id: str) -> Optional[str]:
    encoded_key = os.environ.get("TELEMETRY_USER_HMAC_KEY", "")
    try:
        key = base64.b64decode(encoded_key, validate=True)
    except (ValueError, TypeError):
        return None

    if len(key) < 32:
        return None

    message = f"ncedit7:appinsights-user:v1:{principal_id}".encode("utf-8")
    digest = hmac.new(key, message, hashlib.sha256).digest()
    return "v1_" + base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")


def get_request_identity(request: Request) -> tuple[str, str]:
    azure_principal_id = request.headers.get("x-ms-client-principal-id")
    if azure_principal_id:
        pseudonymous_id = derive_telemetry_user_id(azure_principal_id)
        if pseudonymous_id:
            return pseudonymous_id, "azure_principal"

    browser_id = request.headers.get("x-ncedit-client-id")
    if browser_id:
        return browser_id, "browser"

    return "anonymous", "none"


def set_request_user_context(request: Request, span=None) -> tuple[str, str]:
    user_id, identity_source = get_request_identity(request)
    if user_id == "anonymous":
        return user_id, identity_source

    if span is None:
        if not azure_monitor_enabled:
            return user_id, identity_source
        from opentelemetry import trace
        span = trace.get_current_span()

    span.set_attribute("enduser.pseudo.id", user_id)

    return user_id, identity_source


def summarize_nc_request(payload: Any) -> Dict[str, Any]:
    if isinstance(payload, dict) and "action" in payload:
        return {"action": str(payload.get("action")), "channel_count": 0, "program_chars": 0}

    machinedata = payload.get("machinedata", []) if isinstance(payload, dict) else payload
    if not isinstance(machinedata, list):
        machinedata = []

    entries = [entry for entry in machinedata if isinstance(entry, dict)]
    return {
        "action": "plot",
        "channel_count": len(entries),
        "program_chars": sum(len(str(entry.get("program", ""))) for entry in entries),
        "machines": sorted({str(entry.get("machineName")) for entry in entries if entry.get("machineName")}),
    }


def apply_turn_axis_defaults(states: List[Optional[Any]], machine_name: str = "") -> None:
    from ncplot7py.domain.machines import get_machine_config
    config = get_machine_config(machine_name)
    
    for state in states:
        if state is None:
            continue
        try:
            for axis in config.diameter_axes:
                if state.get_axis_unit(axis).lower() == "radius":
                    state.set_axis_unit(axis, "diameter")
        except Exception:
            continue

# Serve frontend static files (production build) if available.
from pathlib import Path
import os

ROOT_DIR = Path(__file__).resolve().parents[1]
FRONTEND_DIRS = [ROOT_DIR / "dist", ROOT_DIR / "public", ROOT_DIR]
STATIC_DIR = None
for d in FRONTEND_DIRS:
    index_path = d / "index.html"
    if index_path.exists():
        STATIC_DIR = d
        break

if STATIC_DIR is not None:
    # Mount only asset directories to avoid shadowing API POST routes.
    # The built Vite app places hashed assets under `assets/`.
    assets_dir = STATIC_DIR / "assets"
    favicon_dir = STATIC_DIR / "favicon"
    branding_dir = STATIC_DIR / "branding"
    images_dir = STATIC_DIR / "images"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="assets")
    if favicon_dir.exists():
        app.mount("/favicon", StaticFiles(directory=str(favicon_dir)), name="favicon")
    if branding_dir.exists():
        app.mount("/branding", StaticFiles(directory=str(branding_dir)), name="branding")
    if images_dir.exists():
        app.mount("/images", StaticFiles(directory=str(images_dir)), name="images")

    # Expose other top-level static files (like favicon) under /static
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
    # Note: the index route (`/`) will return index.html explicitly.


@app.get("/config.json")
async def config_json():
    if STATIC_DIR is not None:
        config_file = STATIC_DIR / "config.json"
        if config_file.exists():
            return FileResponse(str(config_file), media_type="application/json")
    raise HTTPException(status_code=404, detail="config.json not found")


@app.get("/templates.json")
async def templates_json():
    if STATIC_DIR is not None:
        templates_file = STATIC_DIR / "templates.json"
        if templates_file.exists():
            return FileResponse(str(templates_file), media_type="application/json")
    raise HTTPException(status_code=404, detail="templates.json not found")


@app.get("/favicon.svg")
async def favicon_svg():
    return RedirectResponse(url="/favicon/favicon.svg", status_code=307)


@app.get("/favicon.ico")
async def favicon_ico():
    return RedirectResponse(url="/branding/web/favicon-32.png", status_code=307)


@app.get("/api/syntax/{control_type}")
async def get_syntax(control_type: str):
    """Endpoint providing ACE Editor syntax highlights dynamically by reading machines.json directly."""
    config_path = resolve_machines_config_path()
    
    rules = []
    
    try:
        if config_path is not None and config_path.exists():
            with open(config_path, "r") as f:
                machines_data = json.load(f)
                
            # Scan for the first config matching the control_type to get its syntax_rules
            for key, config in machines_data.items():
                if isinstance(config, dict) and config.get("control_type", "").upper() == control_type.upper():
                    rules = config.get("syntax_rules", [])
                    break
    except Exception as e:
        logging.error(f"Failed to read machines.json for syntax endpoint: {e}")

    # Fallback if no rules found for the control type
    if not rules:
        rules = [
            {"token": "comment.line.modifier", "regex": "^\\s*\\/.*"},
            {"token": "comment", "regex": "\\([^)]*\\)"},
            {"token": "string.quoted.double", "regex": "\"[^\"]*\""},
            {"token": "keyword.control", "regex": "\\b(?:GOTO|IF|WHILE|DO|END)\\b"},
            {"token": "support.function", "regex": "\\b(?:SQRT|ASIN|ACOS|ATAN|SIN|COS|TAN|ABS|BIN|BCD|ROUND|FIX|FUP)\\b"},
            {"token": "keyword.operator", "regex": "[\\+\\-\\*\\/=]"},
            {"token": "variable.parameter", "regex": "#(\\d+)"},
            {"token": "constant.language.gcode", "regex": "[Gg]\\s*\\d+(?:\\.\\d+)?"},
            {"token": "constant.language.mcode", "regex": "[Mm]\\s*\\d+(?:\\.\\d+)?"},
            {"token": ["entity.name.tag", "constant.numeric"], "regex": "([A-Z])(\\s*[+-]?\\d+(?:\\.\\d+)?)"}
        ]
        
    return {"status": "success", "control_type": control_type.upper(), "rules": rules}


SIMULATION_COMMENT_SYNTAX_BY_CONTROL = {
    "FANUC": {"kind": "block", "open": "(", "close": ")"},
    "SIEMENS": {"kind": "line", "prefix": ";"},
}


def get_simulation_comment_syntax(control_type: str) -> Optional[Dict[str, str]]:
    syntax = SIMULATION_COMMENT_SYNTAX_BY_CONTROL.get(control_type.upper())
    return dict(syntax) if syntax else None


def list_machines() -> Dict[str, Any]:
    if get_available_machines is None:
        return {"machines": [], "success": False, "message": "ncplot7py not available"}

    machines = get_available_machines()

    # Add regex patterns and file extensions to each machine
    for machine in machines:
        if get_machine_regex_patterns:
            machine["regexPatterns"] = get_machine_regex_patterns(machine["machineName"])
        config = get_machine_config(machine["machineName"])
        machine.update(config.simulation_metadata())
        if machine["machineName"].startswith("FANUC_STAR"):
            machine["turningReferenceContract"] = "resolved-center-path-v1"
        machine["toolSelection"] = getattr(config, "tool_selection", {})
        machine["controlType"] = getattr(config, "control_type", machine["controlType"])
        machine["machineType"] = getattr(config, "machine_type", "")
        machine["variablePrefix"] = getattr(config, "variable_prefix", "")
        simulation_comment_syntax = get_simulation_comment_syntax(machine["controlType"])
        if simulation_comment_syntax:
            machine["simulationCommentSyntax"] = simulation_comment_syntax
        file_extensions = getattr(config, "file_extensions", None)
        if isinstance(file_extensions, dict) and file_extensions:
            machine["fileExtensions"] = file_extensions

    return {
        "machines": machines,
        "success": True,
    }


def get_line_alignment_syntax() -> Dict[str, Any]:
    return {
        "lineAlignmentSyntax": [
            {
                "controlType": "FANUC",
                "waitCodeRange": {"min": 200, "max": 899},
                "twoChannel": {
                    "syntax": "M<waitCode>",
                    "example": {"channel1": "M200", "channel2": "M200"},
                },
                "threeChannel": {
                    "syntax": "M<waitCode> P<channels>",
                    "selectors": ["P12", "P13", "P23", "P123"],
                    "example": {
                        "channel1": "M899 P123",
                        "channel2": "M899 P123",
                        "channel3": "M899 P123",
                    },
                },
            },
            {
                "controlType": "SIEMENS",
                "syntax": "WAITM(<marker>)",
                "example": {"channel1": "WAITM(1)", "channel2": "WAITM(1)"},
            },
        ],
        "success": True,
    }


@app.get("/api/machines")
async def api_machines():
    return list_machines()


def build_execution_occurrences(control: Any, canal_number: int, segments: List[Dict[str, Any]]):
    # The engine's public get_exected_nodes returns motion-aligned nodes, not all commands.
    # Read its actual execution trace and verify the occurrence contract before publishing it.
    canals = getattr(control, "_canals", None)
    canal = canals.get(canal_number) if isinstance(canals, dict) else None
    nodes = getattr(canal, "_exec_sequence", None)
    if not isinstance(nodes, list):
        logging.warning("Engine command history is unavailable for canal %s; replay is motion-only", canal_number)
        return None
    occurrences = []
    for step, node in enumerate(nodes):
        occurrence = {"executionStep": step}
        line = getattr(node, "nc_code_line_nr", None)
        if line is not None:
            occurrence["lineNumber"] = line
        words = getattr(node, "command_parameter", {})
        if any(str(word).upper() == "T" for word in words):
            occurrence["toolSelection"] = True
        occurrences.append(occurrence)
    for segment in segments:
        step = segment.get("executionStep")
        if step is None:
            continue
        if (
            isinstance(step, bool)
            or not isinstance(step, int)
            or step < 0
            or step >= len(occurrences)
            or occurrences[step].get("lineNumber") != segment.get("lineNumber")
        ):
            raise ValueError("Engine command history does not match motion execution occurrences")
        if segment.get("recordKind") == "state":
            occurrences[step]["toolState"] = {
                key: segment[key] for key in ("toolNumber", "motionContext", "poses")
                if key in segment
            }
    return occurrences


def expand_stationary_linear_motion(segment: Dict[str, Any]) -> None:
    """Expose both endpoints only when the engine proves a stationary feed pose."""
    if (segment.get("geometry") != "LINEAR" or segment.get("traversal") != "FEED"
            or segment.get("sourceCode") not in {"G1", "G01"}):
        return
    points, poses = segment.get("points"), segment.get("poses")
    context = segment.get("motionContext") or {}
    start, end = context.get("startAxes"), context.get("endAxes")
    suffix = str(context.get("channelId") or "")
    complete_axes = {f"{axis}{suffix}" for axis in ("X", "Y", "Z")}
    if (not isinstance(points, list) or len(points) != 1
            or not isinstance(start, dict) or not start or start != end
            or not complete_axes.issubset(start)
            or any(type(value) not in (int, float) or not math.isfinite(value) for value in start.values())):
        return
    position = [points[0].get(axis) for axis in ("x", "y", "z")]
    if any(type(value) not in (int, float) or not math.isfinite(value) for value in position):
        return
    if segment.get("toolNumber") in (None, "unknown", 0, "0") and not poses:
        segment["points"] = [points[0], dict(points[0])]
        return
    if not isinstance(poses, list) or len(poses) != 1:
        return
    pose = poses[0]
    orientation = pose.get("orientation")
    if (pose.get("position") != position
            or not isinstance(orientation, list) or len(orientation) != 4
            or any(type(value) not in (int, float) or not math.isfinite(value) for value in orientation)
            or abs(math.hypot(*orientation) - 1) > 1e-6
            or not pose.get("frameId")
            or pose.get("reference") not in {"millingTip", "turningVirtualTip"}):
        return
    segment["points"] = [points[0], dict(points[0])]
    segment["poses"] = [pose, {**pose, "position": list(position), "orientation": list(orientation)}]


def annotate_execution_record_kinds(control: Any, canal_number: int, segments: List[Dict[str, Any]]) -> None:
    """Separate verified command/reset records from motions in the engine's mixed plot."""
    canals = getattr(control, "_canals", None)
    canal = canals.get(canal_number) if isinstance(canals, dict) else None
    history = getattr(canal, "_exec_sequence", None)
    plotted = getattr(canal, "_tool_nodes", None)
    if not isinstance(history, list) or not isinstance(plotted, list):
        return

    motion_modes = []
    mode = None
    for node in history:
        codes = {str(code).upper() for code in node.g_code}
        explicit = codes.intersection({"G0", "G00", "G1", "G01", "G2", "G02", "G3", "G03"})
        if len(explicit) > 1 or any(code.startswith("G8") and code != "G80" for code in codes):
            mode = None
        elif len(explicit) == 1:
            mode = next(iter(explicit))
        elif "G80" in codes:
            mode = None
        motion_modes.append(mode)

    nodes_by_step = {}
    for node in plotted:
        step = getattr(node, "execution_step", None)
        if step is not None:
            nodes_by_step.setdefault(step, []).append(node)
    for segment in segments:
        if any(segment.get(key) is not None for key in ("geometry", "traversal", "sourceCode")):
            segment["recordKind"] = "motion"
            expand_stationary_linear_motion(segment)
            continue
        segment["recordKind"] = "unknown"
        step = segment.get("executionStep")
        if isinstance(step, bool) or not isinstance(step, int) or not 0 <= step < len(history):
            continue
        candidates = nodes_by_step.get(step, [])
        if len(candidates) != 1:
            continue
        node = candidates[0]
        if node.nc_code_line_nr != segment.get("lineNumber"):
            continue
        codes = {str(code).upper() for code in node.g_code}
        words = {str(word).upper(): value for word, value in node.command_parameter.items()}
        variable = getattr(node, "variable_command", None)
        # A parsed assignment cannot contain axis/modal words. Never infer state from point count.
        assignment = variable is not None and not codes and words.keys() <= {"N"}
        g266_words = words.keys() - {"N"}
        setup = codes == {"G266"} and (
            not g266_words
            or (
                {"A", "X", "W", "S", "Z", "B", "F"}
                <= g266_words
                <= {"A", "X", "W", "S", "Z", "B", "F", "K", "Q", "T"}
            )
        )
        # Modal plane/feed/unit setup on a certified stationary spindle/tool block
        # is not missing cutter geometry (e.g. G0 G18 G99 G97 ... M3 T11).
        command = bool(words.keys() & {"T", "M", "S"}) and codes <= {
            "G0", "G00", "G17", "G18", "G19", "G20", "G21",
            "G40", "G96", "G97", "G98", "G99",
        }
        if "M" in words:
            try:
                command = command and float(words["M"]) in {3, 4, 5, 6, 8, 9}
            except (TypeError, ValueError):
                command = False
        coordinate_words = words.keys() - {"N", "T", "M", "S"}
        if coordinate_words:
            # STAR spindle/tool commands can return generated rapid rotary-reset points
            # without propagating their metadata to the original node. Coordinate blocks
            # are safe to exclude only in a verified rapid modal context, never under feed.
            command = command and coordinate_words <= set("XYZUVWABCH") and motion_modes[step] in {"G0", "G00"}
        context = segment.get("motionContext")
        start = context.get("startAxes") if isinstance(context, dict) else None
        end = context.get("endAxes") if isinstance(context, dict) else None
        unchanged_linear = (
            isinstance(start, dict) and isinstance(end, dict) and bool(start) and start.keys() == end.keys()
            and all(
                isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
                for axes in (start, end) for value in axes.values()
            )
            and all(start[axis] == end[axis] for axis in start if not axis.startswith(("B", "C")))
        )
        if (assignment or setup or command) and unchanged_linear:
            segment["recordKind"] = "state"


def build_segments_from_engine_output(canal_output: Dict[str, Any]) -> Dict[str, Any]:
    """Convert NCExecutionEngine canal output to the frontend response shape."""
    segments = []
    timing = []
    executed_node_lines = canal_output.get("programExec", [])
    motion_line_numbers = []
    line_timing = {}
    variables = canal_output.get("variables", {})
    named_variables = canal_output.get("namedVariables", {})

    plot_list = canal_output.get("plot", [])

    for idx, entry in enumerate(plot_list):
        x = entry.get("x", [])
        y = entry.get("y", [])
        z = entry.get("z", [])
        t = entry.get("t", 0)

        if len(x) == 0:
            continue

        points = []
        point_count = max(len(x), len(y), len(z))
        for point_idx in range(point_count):
            points.append({
                "x": x[point_idx] if point_idx < len(x) else (x[-1] if len(x) > 0 else 0),
                "y": y[point_idx] if point_idx < len(y) else (y[-1] if len(y) > 0 else 0),
                "z": z[point_idx] if point_idx < len(z) else (z[-1] if len(z) > 0 else 0),
            })

        geometry = entry.get("geometry")
        traversal = entry.get("traversal")
        source_code = entry.get("sourceCode")
        motion_context = entry.get("motionContext")
        machining_mode = entry.get("machiningMode")
        if "machiningMode" not in entry and isinstance(motion_context, dict):
            machining_mode = motion_context.get("machiningMode")
        if machining_mode is None:
            machining_mode = "unknown"
        if machining_mode not in ("turning", "milling", "unknown"):
            raise ValueError(f"Invalid engine machining mode: {machining_mode!r}")

        line_number = entry.get("lineNumber")
        if line_number is None and idx < len(executed_node_lines):
            line_number = executed_node_lines[idx]

        seg = {
            "geometry": geometry,
            "traversal": traversal,
            "sourceCode": source_code,
            "machiningMode": machining_mode,
            "lineNumber": line_number,
            "executionStep": entry.get("executionStep"),
            "toolNumber": entry.get("toolNumber", "unknown"),
            "motionContext": motion_context,
            "poses": entry.get("poses"),
            "points": points,
        }
        segments.append(seg)
        try:
            segment_time = float(t)
        except Exception:
            segment_time = 0.0
        timing.append(segment_time)
        motion_line_numbers.append(line_number)
        if line_number is not None:
            line_key = str(line_number)
            line_timing[line_key] = line_timing.get(line_key, 0.0) + segment_time

    return {
        "segments": segments,
        "executedLines": motion_line_numbers,
        "executedNodeLines": executed_node_lines,
        "variables": variables if isinstance(variables, dict) else {},
        "namedVariables": named_variables if isinstance(named_variables, dict) else {},
        "timing": timing,
        "lineTiming": line_timing,
    }


@app.get("/")
async def index():
    """Return the frontend `index.html` when available, otherwise a JSON status.

    If the environment variable `FRONTEND_URL` is set (for dev), redirect there.
    """
    # If static files were mounted, StaticFiles will already serve index.html.
    if STATIC_DIR is not None:
        index_file = STATIC_DIR / "index.html"
        if index_file.exists():
            return FileResponse(str(index_file), media_type="text/html")

    # Dev fallback: redirect to dev server if configured
    frontend_url = os.environ.get("FRONTEND_URL")
    if frontend_url:
        return RedirectResponse(frontend_url)

    return {"service": "ncplot7py-adapter-import", "status": "ok", "note": "No frontend build found"}


def sanitize_program(program: str) -> str:
    """Conservative sanitizer exposed at module level for reuse and testing.

    - Removes parenthetical comments ("(comment)").
    - Splits lines by semicolon `;` into sub-commands and processes each
      sub-command separately.
    - In each sub-command removes duplicate axis tokens (X/Y/Z/I/J/K),
      keeping the last occurrence so explicit later overrides win.
    - Preserves other tokens and reassembles semicolon-separated commands.
    """
    if not isinstance(program, str):
        return program

    # Remove parenthetical comments (single-line)
    # DISABLED: Siemens uses () for parameters (e.g. CYCLE800(...))
    # program = re.sub(r"\(.*?\)", "", program)
    # We should only remove comments if we are sure they are comments.
    # For now, let the parser handle comments.

    def sanitize_subcmd(sub: str) -> str:
        parts = [p for p in sub.strip().split() if p != ""]
        axis_re = re.compile(r'^([A-Z])(?![A-Za-z_])', re.IGNORECASE)
        last_axis = {}
        others = []
        # record last index for axis tokens and keep others with position
        for i, p in enumerate(parts):
            m = axis_re.match(p)
            if m:
                last_axis[m.group(1).upper()] = i
            else:
                others.append((i, p))

        if not last_axis and not others:
            return sub.strip()

        axis_by_index = {idx: parts[idx] for idx in last_axis.values()}

        merged = []
        for i in range(len(parts)):
            if i in axis_by_index:
                merged.append(axis_by_index[i])
            else:
                # append any other token at this position
                for pos, val in others:
                    if pos == i:
                        merged.append(val)
                        break

        return " ".join(merged)

    sanitized_lines = []
    for line in program.splitlines():
        # split by semicolon but keep semantic separators
        subs = [s for s in line.split(";")]
        san_subs = [sanitize_subcmd(s) for s in subs]
        sanitized_lines.append(";".join([s for s in san_subs if s is not None]))

    return "\n".join(sanitized_lines)


def mock_parse_nc_program(program: str, machine_name: str) -> Dict[str, Any]:
    """
    Parse NC program and generate mock plot data (legacy behavior).
    Copied from ncplot7py/scripts/cgiserver.cgi to ensure compatibility.
    """
    lines = [line.strip() for line in program.split('\n') if line.strip()]

    # Generate mock plot segments
    segments = []

    # Track programmed coordinates separately from plotted world coordinates.
    # C rotates the coordinate system around Z, so local X/Y stay unchanged
    # while the plotted point is transformed by the current C angle.
    current_local = {"x": 0.0, "y": 0.0, "z": 0.0, "c": 0.0}

    def to_plot_point(local_pos: Dict[str, float]) -> Dict[str, float]:
        angle_rad = math.radians(local_pos["c"])
        x = local_pos["x"] * math.cos(angle_rad) - local_pos["y"] * math.sin(angle_rad)
        y = local_pos["x"] * math.sin(angle_rad) + local_pos["y"] * math.cos(angle_rad)
        return {"x": x, "y": y, "z": local_pos["z"]}
    
    for i, line in enumerate(lines):
        # Simple G-code parsing for demo
        if line.startswith('G0') or line.startswith('G1'):
            # Extract coordinates in programmed space
            new_local = current_local.copy()

            parts = line.split()
            for part in parts:
                if part.startswith('X'):
                    try:
                        new_local['x'] = float(part[1:])
                    except ValueError:
                        pass
                elif part.startswith('Y'):
                    try:
                        new_local['y'] = float(part[1:])
                    except ValueError:
                        pass
                elif part.startswith('Z'):
                    try:
                        new_local['z'] = float(part[1:])
                    except ValueError:
                        pass
                elif part.startswith('C'):
                    try:
                        new_local['c'] = float(part[1:])
                    except ValueError:
                        pass
                elif part.startswith('H'):
                    try:
                        new_local['c'] += float(part[1:])
                    except ValueError:
                        pass

            delta_c = new_local['c'] - current_local['c']
            segment_count = 1
            if abs(delta_c) > 1e-9:
                segment_count = max(2, int(math.ceil(abs(delta_c) / 10.0)))

            points = []
            for step in range(segment_count + 1):
                t = step / segment_count
                interpolated_local = {
                    'x': current_local['x'] + (new_local['x'] - current_local['x']) * t,
                    'y': current_local['y'] + (new_local['y'] - current_local['y']) * t,
                    'z': current_local['z'] + (new_local['z'] - current_local['z']) * t,
                    'c': current_local['c'] + delta_c * t,
                }
                points.append(to_plot_point(interpolated_local))

            # Create segment
            segment = {
                "geometry": "LINEAR",
                "traversal": "RAPID" if line.startswith('G0') else "FEED",
                "sourceCode": "G00" if line.startswith('G0') else "G01",
                "lineNumber": i + 1,
                "toolNumber": 1,
                "points": points,
            }
            segments.append(segment)
            current_local = new_local
    
    return {
        "segments": segments,
        "executedLines": list(range(1, len(lines) + 1)),
        "variables": {},
        "namedVariables": {},
        "timing": [0.1] * len(lines)
    }


def engine_output_has_non_plot_data(engine_output: Any) -> bool:
    """Return True when the real engine produced useful non-geometry data."""
    if not isinstance(engine_output, list):
        return False

    for canal in engine_output:
        if not isinstance(canal, dict):
            continue
        if canal.get("programExec"):
            return True
        variables = canal.get("variables")
        if isinstance(variables, dict) and variables:
            return True
        named_variables = canal.get("namedVariables")
        if isinstance(named_variables, dict) and named_variables:
            return True
    return False


def run_mock_parser(machinedata: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Run the mock parser for all programs in machinedata."""
    canal_results = {}
    messages = []
    
    for program_entry in machinedata:
        program = program_entry.get("program", "")
        machine_name = program_entry.get("machineName", "SIEMENS_MILL")
        canal_nr = str(program_entry.get("canalNr", "1"))
        
        # Parse program
        try:
            result = mock_parse_nc_program(program, machine_name)
            canal_results[canal_nr] = result
            messages.append(f"Successfully processed {machine_name} canal {canal_nr} (mock)")
        except Exception as e:
            messages.append(f"Error processing {machine_name} canal {canal_nr}: {str(e)}")
    
    return {
        "canal": canal_results,
        "message": messages,
        "success": True
    }


@app.post("/cgiserver_import", dependencies=[Depends(verify_api_key)])
async def cgiserver_import(request: Request):
    if NCExecutionEngine is None or UniversalConfigDrivenControl is None:
        logging.warning("ncplot7py package not importable in this environment; some actions will be limited")

    try:
        raw_body = await request.body()
        try:
            req = json.loads(raw_body.decode("utf-8") if raw_body else "{}")
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid JSON request body")
    except Exception:
        raise HTTPException(status_code=400, detail="Unable to read request body")

    user_id, identity_source = set_request_user_context(request)
    request_id = request.headers.get("x-request-id") or str(uuid.uuid4())
    telemetry_logger.info("NC_REQUEST %s", json.dumps({
        "event": "nc_program_request",
        "request_id": request_id,
        "user_id": user_id,
        "identity_source": identity_source,
        "method": request.method,
        "path": request.url.path,
        **summarize_nc_request(req),
    }, separators=(",", ":")))

    # Ensure parser registration
    try:
        if cli_bootstrap:
            cli_bootstrap()
    except Exception:
        logging.exception("Bootstrap failed")

    # Handle actions
    if isinstance(req, dict) and "action" in req:
        action = req.get("action")
        if action in ["list_machines", "get_machines"]:
            return list_machines()
        elif action in [
            "get_line_alignment_syntax",
            "get_multichannel_alignment_syntax",
            "get_sync_syntax",
        ]:
            return get_line_alignment_syntax()
        else:
            raise HTTPException(status_code=400, detail=f"Unknown action: {action}")

    # Handle machinedata
    machinedata = None
    if isinstance(req, dict) and "machinedata" in req:
        machinedata = req.get("machinedata")
    elif isinstance(req, list):
        machinedata = req
    else:
        raise HTTPException(status_code=400, detail="Invalid request format")

    tool_path_mode = req.get("toolPathMode", "effective") if isinstance(req, dict) else "effective"
    if tool_path_mode not in ("effective", "center"):
        raise HTTPException(status_code=400, detail="toolPathMode must be effective or center")

    if NCExecutionEngine is None or UniversalConfigDrivenControl is None:
        return {"success": False, "canal": {}, "message": ["NC execution engine unavailable"],
                "errors": [{"code": "ENGINE_EXECUTION_FAILED", "message": "NC execution engine unavailable"}]}
    try:
        profiles = {machine["machineName"]: get_machine_config(machine["machineName"])
                    for machine in get_available_machines()}
        validate_pose_request(engine_pose_request(req), profiles)
    except SimulationContractError as error:
        return {
            "success": False, "canal": {}, "message": [str(error)],
            "errors": [error.as_dict()],
        }

    # Build programs list, canal names, tool values, custom variables, and machine names
    programs: List[str] = []
    canal_names: List[str] = []
    tool_values_list: List[List[Dict[str, Any]]] = []
    custom_variables_list: List[List[Dict[str, Any]]] = []
    machine_names: List[str] = []
    # use module-level `sanitize_program` defined above

    for entry in machinedata:
        prog = entry.get("program", "")
        # Bypass sanitizing for testing @todo check nessessary 
        prog_sanitized = prog
        programs.append(prog_sanitized)
        canal_names.append(str(entry.get("canalNr", "1")))
        machine_names.append(str(entry.get("machineName", "SIEMENS_MILL")))
        
        # Extract toolValues (Q quadrant 1-9 and R radius for tool compensation)
        tool_values = entry.get("toolValues", [])
        tool_values_list.append(tool_values)
        
        # Extract customVariables (user-defined variables)
        custom_vars = entry.get("customVariables", [])
        custom_variables_list.append(custom_vars)

    # Create initial CNC states with custom variables and tool data
    init_states = []
    for idx in range(len(programs)):
        if CNCState is not None:
            state = CNCState(tool_path_mode=tool_path_mode)
            machine_name = machine_names[idx] if idx < len(machine_names) else ""
            if machine_name:
                try:
                    state.machine_config = get_machine_config(machine_name)
                except Exception:
                    logging.warning("Failed to load machine config for %s", machine_name)

            # Set custom variables into state parameters
            custom_vars = custom_variables_list[idx] if idx < len(custom_variables_list) else []
            for var in custom_vars:
                var_name = str(var.get("name", ""))
                var_value = var.get("value", 0)
                if var_name:
                    try:
                        state.set_parameter(var_name, float(var_value))
                    except (ValueError, TypeError):
                        logging.warning("Invalid custom variable value")
            
            # Store tool Q/R values in state extra for later use by tool compensation handlers
            tool_vals = tool_values_list[idx] if idx < len(tool_values_list) else []
            try:
                load_tool_data(state, tool_vals, machinedata[idx].get("toolOffsets", []))
            except ValueError as error:
                raise HTTPException(status_code=400, detail=str(error)) from error
            simulation = machinedata[idx].get("simulation")
            if isinstance(simulation, dict):
                state.extra["pose_tools"] = {
                    tool["toolNumber"]: {
                        "reference": tool["reference"],
                        "mountingOrientationDegrees": list(tool["mountingOrientationDegrees"]),
                    }
                    for tool in simulation.get("tools", [])
                }
            init_states.append(state)
        else:
            init_states.append(None)

    # Determine control type based on machine name
    # Default to SIEMENS_MILL (Siemens-style) when no machine is specified
    first_machine = machine_names[0] if machine_names else ""
    apply_turn_axis_defaults(init_states, first_machine)

    # Create a control that can handle multiple canals and run the engine.
    engine_output = None
    errors: List[Dict[str, Any]] = []
    try:
        # Choose control type based on machine
        control = UniversalConfigDrivenControl(
            count_of_canals=len(programs), 
            canal_names=canal_names,
            init_nc_states=init_states if any(s is not None for s in init_states) else None
        )
        engine = NCExecutionEngine(control)
        engine_output = engine.get_Syncro_plot(programs, False)
        
        # Collect any errors from the engine
        errors = getattr(engine, 'errors', [])
    except ExceptionNode as e:
        # Handle structured NC errors
        error_info = {
            "type": e.typ.name if hasattr(e.typ, 'name') else str(e.typ),
            "code": e.code,
            "line": e.line,
            "message": e.localized("en"),
            "value": str(e.value) if e.value else "",
        }
        errors.append(error_info)
        logging.warning("NC execution error: %s", error_info)
    except Exception as e:
        logging.exception("NC execution failed")
        return {"success": False, "canal": {}, "message": ["NC execution failed"],
                "errors": [{"code": "ENGINE_EXECUTION_FAILED", "message": "NC execution failed"}]}

    if engine_output is None or errors:
        return {"success": False, "canal": {}, "message": ["NC execution failed"],
                "errors": errors or [{"code": "ENGINE_EXECUTION_FAILED", "message": "No engine result"}]}

    # engine_output is a list per canal
    canal_results = {}
    messages = []
    for idx, canal in enumerate(engine_output):
        canal_nr = canal_names[idx] if idx < len(canal_names) else str(idx + 1)
        try:
            # The engine is expected to return a dict per canal. In some
            # situations it may return a raw list (plot points) — normalize
            # that to the expected dict shape to avoid attribute errors.
            if isinstance(canal, list):
                logging.info("Normalizing canal output: list -> dict (plot)")
                canal = {"plot": canal, "programExec": []}

            converted = build_segments_from_engine_output(canal)
            annotate_execution_record_kinds(control, idx + 1, converted["segments"])
            if isinstance(req, dict):
                resolve_turning_references(control, idx + 1, converted["segments"], req, machine_names[idx])
            occurrences = build_execution_occurrences(control, idx + 1, converted["segments"])
            if occurrences is not None:
                converted["executionOccurrences"] = occurrences
            canal_results[canal_nr] = converted
            messages.append(f"Successfully processed canal {canal_nr}")
        except Exception as e:
            logging.exception("Failed converting canal output for canal %s", canal_nr)
            # Return a structured response instead of letting FastAPI raise 500
            return {
                "canal": canal_results,
                "message": [f"Conversion error for canal {canal_nr}: {str(e)}", f"raw_output: {repr(canal)[:1000]}"],
                "success": False,
                "errors": errors,
            }

    response = {"canal": canal_results, "message": messages, "success": True, "executionOrigin": "engine"}
    return response


# Backwards-compatible legacy CGI path used by the frontend
@app.api_route("/ncplot7py/scripts/cgiserver.cgi", methods=["POST", "OPTIONS", "GET"])
async def legacy_cgiserver(request: Request):
    """Legacy endpoint to keep compatibility with frontends that post to
    `/ncplot7py/scripts/cgiserver.cgi`. POST requests are forwarded to the
    import adapter handler. GET returns the frontend index or a small JSON
    status so browsers don't receive Method Not Allowed or 404 errors.
    """
    # Handle preflight
    if request.method == "OPTIONS":
        return {"status": "ok"}

    if request.method == "GET":
        # Return index.html when available (same behavior as root)
        if STATIC_DIR is not None:
            index_file = STATIC_DIR / "index.html"
            if index_file.exists():
                return FileResponse(str(index_file), media_type="text/html")
        frontend_url = os.environ.get("FRONTEND_URL")
        if frontend_url:
            return RedirectResponse(frontend_url)
        return {"service": "ncplot7py-adapter-import", "status": "ok"}

    # For POST, reuse the cgiserver_import handler to process the body.
    # Manually verify API key for legacy endpoint since it handles multiple methods
    if request.method == "POST":
        x_api_key = request.headers.get("X-API-Key")
        if x_api_key != API_KEY:
             raise HTTPException(status_code=403, detail="Invalid or missing API Key")

    try:
        return await cgiserver_import(request)
    except HTTPException:
        # Re-raise HTTPExceptions so status codes are preserved
        raise
    except Exception:
        logging.exception("Unhandled error in legacy_cgiserver")
        raise HTTPException(status_code=500, detail="Internal server error")

# --- Features Endpoint ---

@app.get("/api/features")
async def get_features():
    """Endpoint for frontend to query which backend modules are available."""
    return {
        "transfer_enabled": ENABLE_TRANSFER and TRANSFER_IMPORT_OK,
        "transfer_protocols": ["focas", "usb"] if ENABLE_TRANSFER and TRANSFER_IMPORT_OK else [],
        "cgi_path": ""  # Only relevant for main.py subprocess
    }
